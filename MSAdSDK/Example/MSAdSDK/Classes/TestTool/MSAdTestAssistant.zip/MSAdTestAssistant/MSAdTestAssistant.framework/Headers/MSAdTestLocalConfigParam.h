//
//  MSAdTestLocalConfigParam.h
//  MSAdTestAssistant
//
//  Created by leej on 2023/3/24.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface MSAdTestLocalConfigParam : NSObject
@property(nonatomic,copy)NSString *splashAdConfigFileName;
@property(nonatomic,copy)NSString *bannerAdConfigFileName;
@property(nonatomic,copy)NSString *nativeFeedAdConfigFileName;
@property(nonatomic,copy)NSString *fullScreenAdConfigFileName;
@property(nonatomic,copy)NSString *rewardAdConfigFileName;
@property(nonatomic,copy)NSString *interstitialAdConfigFileName;
@property(nonatomic,copy)NSString *drawAdConfigFileName;
@end

NS_ASSUME_NONNULL_END
