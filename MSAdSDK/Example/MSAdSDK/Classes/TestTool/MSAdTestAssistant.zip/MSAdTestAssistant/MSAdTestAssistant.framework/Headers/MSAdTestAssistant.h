//
//  MSAdTestAssistant.h
//  MSAdTestAssistant
//
//  Created by leej on 2023/3/9.
//

#import <Foundation/Foundation.h>
#import "MSAdTestLocalConfigParam.h"
NS_ASSUME_NONNULL_BEGIN

@interface MSAdTestAssistant : NSObject
+ (MSAdTestAssistant *)shareInstance;
+ (NSString *)testAssistantVersion;
- (void)startWithAsyncCompletionHandler:(MSAdTestLocalConfigParam * _Nullable (^)(BOOL success,NSError * _Nullable error))completionHandler;
@end

NS_ASSUME_NONNULL_END

